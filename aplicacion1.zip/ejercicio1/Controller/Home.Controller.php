<?php
Class Home
{
    public function Inicio()
    {
        echo "En inicio";
    }
}

?>