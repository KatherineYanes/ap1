<?php

Class User
{
    public Function Login ()
    {
        echo "en login";
    }

    public Function Update ()
    {
        echo "en update";
    }

    public Function Delet ()
    {
        echo "en delet";
    }
}

?>