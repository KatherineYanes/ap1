<<?php
Class Inventario
{
    public function VerInventario( )
    {
         echo "en ver inventario";
    }
   public funtion IngresoInventario()
   {
       echo "en ingreso inventario";
   }
  
}
   

?>